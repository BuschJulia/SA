import { TelaLogin } from './pages/TelaLogin'

function App() {

  return (
    <>
      <TelaLogin/>
    </>
  )
}

export default App
