import Cadastrese from '../components/Cadastrese';

import React from 'react'

function CadastroUsuario() {
    return (
        <div>
            <Cadastrese />
        </div>
    )
}

export default CadastroUsuario